let entero = 1357; 
let decimal = 135.7; 
let cientifico = 135e7; 
let octal = 0o1357; 
let hexadecimal = 0x1357; 

//Mostrara el numero entero
alert("Numero entero: " + entero); 
//Mostrara el numero decimal
alert("Numero decimal: " + decimal);
//Mostrara el numero ya transformado a decimal
alert("Numero en notación cientifica: " + cientifico); 
//Mostrara el numero ya transformado a decimal
alert("Numero octal: " + octal); 
//Mostrara el numero ya transformado a decimal
alert("Numero hexadecimal: " + hexadecimal); 