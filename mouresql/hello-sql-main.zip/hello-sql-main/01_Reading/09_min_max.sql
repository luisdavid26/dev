/*
MIN, MAX
Lección 10.3: https://youtu.be/OuJerKzV5T0?t=7834
*/

-- Obtiene el valor menor del campo edad de la tabla "users"
Select MIN(age) FROM users;

-- Obtiene el valor mayor del campo edad de la tabla "users"
Select MAX(age) FROM users;