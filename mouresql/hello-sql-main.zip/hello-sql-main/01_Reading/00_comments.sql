/*
COMENTAROS
Lección 10.1: https://youtu.be/OuJerKzV5T0?t=7512
*/

-- Comentario en una lína

/*
Este
es
un
comentario
en
varias
líneas
*/