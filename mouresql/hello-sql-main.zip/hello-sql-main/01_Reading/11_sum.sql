/*
SUM
Lección 10.5: https://youtu.be/OuJerKzV5T0?t=8128
*/

-- Suma todos los valores del campo edad de la tabla "users"
Select SUM(age) FROM users;