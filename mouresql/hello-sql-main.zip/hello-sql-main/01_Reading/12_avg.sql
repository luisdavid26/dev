/*
AVG
Lección 10.6: https://youtu.be/OuJerKzV5T0?t=8293
*/

-- Obitne la media de edad de la tabla "users"
Select AVG(age) FROM users;