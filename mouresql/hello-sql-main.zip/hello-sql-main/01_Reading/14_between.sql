/*
BETWEEN
Lección 10.8: https://youtu.be/OuJerKzV5T0?t=8559
*/

-- Ordena todos los datos de la tabla "users" con edad comprendida entre 20 y 30
SELECT * FROM users WHERE age BETWEEN 20 AND 30