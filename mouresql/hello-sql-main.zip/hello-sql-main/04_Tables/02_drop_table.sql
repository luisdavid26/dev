/*
DROP TABLE
Lección 13.8: https://youtu.be/OuJerKzV5T0?t=12412
*/

-- Elimina la tabla llamada "persons8"
DROP TABLE persons8;