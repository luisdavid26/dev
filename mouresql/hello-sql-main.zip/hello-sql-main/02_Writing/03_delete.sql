/*
DELETE
Lección 11.3: https://youtu.be/OuJerKzV5T0?t=10920
*/

-- Elimina el registro de la tabla "users" con identificador igual a 11
DELETE FROM users WHERE user_id = 11;