class Auto {
    #encendido = false;
    #velocidad = 0;
    #marca;
    #modelo;
    #patente;

    constructor(marca, modelo, patente) {
        this.#marca = marca;
        this.#modelo = modelo;
        this.#patente = patente;
    }

    //metodos
    arrancar() {
        return this.#encendido = true;
    }

    apagar() {
        if (this.#velocidad === 0) {
            return this.#encendido = false;
        }
    }

    acelerar() {
        if (this.#encendido) {
            return this.#velocidad += 10;
        }
    }

    desacelerar() {
        if (this.#encendido && (this.#velocidad - 10 >= 0)) {
            return this.#velocidad -= 10;
        }

    }

    toString() {
        return `${this.#marca} ${this.#modelo}, patente ${this.#patente}`;
    }

    getVelocidad() {
        return this.#velocidad;
    }
}

// Ejemplo de uso: 
const miAuto = new Auto('Toyota', 2021, 'ABC123');
console.log(miAuto.toString()); // Toyota 2021, patente ABC123 
miAuto.arrancar();
miAuto.acelerar();
console.log(miAuto.getVelocidad()); // 10 
miAuto.desacelerar();
console.log(miAuto.getVelocidad()); // 0 
miAuto.apagar();