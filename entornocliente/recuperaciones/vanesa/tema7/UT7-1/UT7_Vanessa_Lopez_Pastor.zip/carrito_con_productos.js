class Producto {
    #id;
    #nombre;
    #precio;
    #cantidad;
    #tieneImpuesto;

    constructor(nombre, precio, cantidad, tieneImpuesto) {
        this.#nombre = nombre;
        this.#precio = precio;
        this.#cantidad = cantidad;
        this.#tieneImpuesto = tieneImpuesto;
        this.#generarId();
    }

    //getters
    //nombre
    get nombre() {
        return this.#nombre;
    }

    //precio
    get precio() {
        return this.#precio;
    }

    //tieneImpuesto
    get tieneImpuesto() {
        return this.#tieneImpuesto;
    }

    //getters y setters
    //cantidad
    get cantidad() {
        return this.#cantidad;
    }

    setCantidad(cantidad) {
        if (!this.#cantidad <= 0) {
            this.#cantidad = cantidad;
        }
    }

    //metodos
    #generarId() {
        this.#id += 1;
    }

    getId() {
        return this.#id;
    }

}

class Carrito {
    #productos = [];

    //metodos
    agregarProducto(producto) {
        this.#productos.push(producto);
    }

    actualizarCantidadProducto(id, cantidad) {
        this.#productos.forEach(p => {
            if (id === p.getId()) {
                p.setCantidad(cantidad);
            }
        });
    }

    eliminarProducto(id) {
        this.#productos.forEach(p => {
            if (id === p.getId()) {
                this.#productos.splice();
            }
        });
    }

    calcularTotal() {
        let total = 0;

        this.#productos.forEach(p => {
            total += p.precio;
        });

        return total;
    }

    calcularImpuestoTotal() {
        let totalImpuestos = 0;

        this.#productos.forEach(p => {
            if(p.tieneImpuesto){
                totalImpuestos = p.precio*0.1;
            }
        });

        return totalImpuestos.toFixed(2);
    }

    obtenerCantidadTotal() {
        this.#productos.forEach(p => {
            console.log(`Producto: ${p.nombre}. Cantidad: ${p.cantidad}`);
        });
    }

    toString() {
        this.#productos.forEach(p => {
            console.log(`
            Nombre: ${p.nombre}
            Precio por unidad: ${p.precio}
            Cantidad: ${p.cantidad}
            Subtotal sin impuesto: 
            Subtotal con impuestos: ${p.calcularImpuestoTotal}
            Total final: ${p.calcularTotal}`);
        });
    }
}

// Ejemplo de uso: 
const producto1 = new Producto('Manzana', 1.5, 10, true);
const producto2 = new Producto('Pan', 2, 5, false);
const carrito = new Carrito();

carrito.agregarProducto(producto1);
carrito.agregarProducto(producto2);

console.log(carrito.toString());
console.log('Total con impuestos:', carrito.calcularTotal());
console.log('Total impuestos:', carrito.calcularImpuestoTotal());
console.log('Cantidad total de ítems:', carrito.obtenerCantidadTotal());

carrito.actualizarCantidadProducto(producto1.getId(), 20);
console.log(carrito.toString());

carrito.eliminarProducto(producto2.getId());
console.log(carrito.toString());