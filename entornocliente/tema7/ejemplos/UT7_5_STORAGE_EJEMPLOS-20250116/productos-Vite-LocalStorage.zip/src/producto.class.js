export class Producto {
    constructor(name, description, photo) {
        this.name = name;
        this.description = description;
        this.photo = photo;
    }
}
