//export const SERVER = "http://localhost:5000"; // cambiar en función de json-mock o mongodb
export const SERVER = "http://localhost:8000"; // cambiar en función de json-mock o mongodb