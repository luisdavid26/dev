let personas=[
  ["Adrián",47, "Profesor"],
  ["Luisa",60, "Profesor"],
  ["Ana",20, "Estudiante"],
  ["Blas",36, "Estudiante"],
  ["Agustín",50, "Profesor"],
  ["Felipe",25, "Estudiante"],
  ["Pedro",19, "Estudiante"],
  ["Zoraida",36, "Estudiante"],
  ["Juan",36, "Administrativo"],
  ["Toñi",48, "Administrativo"],
  ["Juan",16, "Estudiante"],
  ["Miriam",15, "Estudiante"],
  ["Rosa",75, "Estudiante"],
  ["Pepe",31, "Estudiante"],
  ["Fermín",64, "Estudiante"],
  ["Jose",47, "Profesor"]
];