let elementos = ["Dragonborn", "Skyrim", "Dovahkiin", "Dragon", "Fire", "Game"];

//mostramos ellargo del array y el contenido
console.log("el numero de elementos en el array es:" + elementos.length);
console.log("contenido del array: " + elementos);

//borramos el ultimo elemento de la cadena
let ultimo=elementos.pop();

//mostramos el largo del array el contenido final
console.log("el numero de elementos en el array es: " + elementos.length);
console.log("contenido del array: " + elementos);
console.log("contenido eliminado del array: " + ultimo);
