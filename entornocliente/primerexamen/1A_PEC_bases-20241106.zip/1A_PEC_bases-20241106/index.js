let menu = true;

while (menu) {
  var opcion = prompt(
    "Selecciona una opción:\n1. Ventas por Vendedor (componentes) \n2. Ventas por Sucursal (número) \n3. Cantidad Ventas Componente\n4. Presupuesto PC \n5. Ventas Totales por Vendedor (número) \n6. Salir"
  );
  switch (opcion) {
    case "1":
      let nomvendusu = prompt(
        `dime el nombre del vendedor por el que quieres buscar`
      );
      ventasVendedores(nomvendusu, ventas.vendedores);
      break;

    case "2":
      let nomsucusu = prompt(
        `dime el nombre de la sucursal por la que quieres buscar`
      );
      ventasSucursal(nomsucusu, ventas.vendedores);
      break;
    case "3":
      let nomcompousu = prompt(
        `dime el nombre del componente por la que quieres buscar`
      );
      cantidadVentasComponente(nomcompousu, ventas.vendedores);
      break;

    case "4":
      let nombresdeloscompo = prompt(
        `dime los nombres de los componentes  para el presupuesto (separados por por coma ",")`
      );
      presupuestoPC(nombresdeloscompo, ventas.precios);
      break;

    case "5":
      break;

    case "6":
      alert("Adiós!");
      menu = false;
      break;
  }
}
