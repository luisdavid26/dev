function ventasVendedores(nomventausu, vendedores) {
  // let ventasresul = ventas.detalle.filter((vendedor)=>nomventausu== detalle.nombreVendedore);
  console.log(`ventas :${vendedores}:`);
  console.log(`------------------------------------------`);
  try {
    ventas.detalle.forEach((detalle) => {
      //recorremos le array para encontrar las ventas que tengan el mismo nombre de vendedor del que a puesto el ususario
      if ((nomventausu = detalle.nombreVendedore)) {
        let dia = detalle.fecha.getDay(); //recogemos el dia
        let mes = detalle.fecha.getMonth(); //recogemos el mes
        let anyo = detalle.fecha.getFullYear(); //recogemos el anyo
        console.log(`${dia}/${mes}/${anyo} : ${detalle.componentesPC}}`); //mostramos la venta con la fecha formateada y los compomentes del pc que tenia la venta
      }
    });
  } catch (error) {
    console.error(`a ocurrido un error`); //si ocurre un error lo manejamos con el try catch
  }
}
function ventasSucursal(nomsucu, sucursal) {
  let contadorsucu = 0;
  console.log(`ventas sucursal :${nomsucu}:`);
  console.log(`------------------------------------------`);
  try {
    ventas.detalle.forEach((detalle) => {
      //recorremos le array para encontrar las ventas que tengan el mismo nombre de la sucursal
      if (nomsucu == detalle.sucursal) {
        // si el nombre de la sucursal es igual que el el nombre pasado por el usuario , aumentamos el contador
        contadorsucu++;
      }
    });
    console.log(`${contadorsucu}`);
  } catch (error) {
    console.error(`a ocurrido un error`); //si ocurre un error lo manejamos con el try catch
  }
}
function cantidadVentasComponente(nomcomponenteusu, componente) {
  let contadorcompo = 0;
  componente = ventas.detalle.componentesPC;
  console.log(`ventas por componente: ${nomcomponenteusu}:`);
  console.log(`------------------------------------------`);
  ventas.detalle.forEach((detalle) => {
    //recorremos le array para encontrar las ventas que tengan el mismo nombre de componente
    if (nomcomponenteusu == detalle.componentesPC[0]) {
      // si el nombre del componente es igual que el el nombre pasado por el usuario , aumentamos el contador
      contadorcompo++;
    }
    if (nomcomponenteusu == detalle.componentesPC[1]) {
      // si el nombre del componente es igual que el el nombre pasado por el usuario , aumentamos el contador
      contadorcompo++;
    }
  });
  console.log(`${contadorcompo}`);
}
function presupuestoPC(componentesusu, ventas) {
  let totalpres = 0;
  // let ventasresul = ventas.detalle.filter((vendedor)=>nomventausu== detalle.nombreVendedore);
  console.log(`presupuesto del pc :${componentesusu}:`);
  console.log(`------------------------------------------`);
  let arrcompousu = componentesusu.split(",");
  let precioscomponentes = ventas.precios;
  //    arrcompousu.forEach((precios) => {
  //      //recorremos le array para encontrar los precios de los componentes e ir haciendo el presupuesto
  //      if (arrcompousu=precios.componente) {
  //        console.log("entra");
  //      }
  //    });
  for (let i = 0; i < arrcompousu.length; i++) {
    if (arrcompousu[i] == precioscomponentes[i]) {
      totalpres = totalpres + precioscomponentes.precios;
    }
  }
  console.log(`presuspuesto total : ${totalpres}`);
}
function ventasTotalesVendedore(ventatotalusu, ventas) {
  console.log(`ventas :${vendedores}:`);
  console.log(`------------------------------------------`);
  try {
    ventas.detalle.forEach((detalle) => {
      //recorremos le array para encontrar las ventas que tengan el mismo nombre de vendedor del que a puesto el ususario
      if ((ventatotalusu = detalle.nombreVendedore)) {
        let dia = detalle.fecha.getDay(); //recogemos el dia
        let mes = detalle.fecha.getMonth(); //recogemos el mes
        let anyo = detalle.fecha.getFullYear(); //recogemos el anyo
        console.log(`${dia}/${mes}/${anyo} : ${detalle.componentesPC}}`); //mostramos la venta con la fecha formateada y los compomentes del pc que tenia la venta
      }
      
    });
  } catch (error) {
    console.error(`a ocurrido un error`); //si ocurre un error lo manejamos con el try catch
  }
}
